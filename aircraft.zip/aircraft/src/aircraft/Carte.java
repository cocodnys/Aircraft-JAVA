/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraft;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;
import org.jxmapviewer.*;
import org.jxmapviewer.input.*;
import org.jxmapviewer.viewer.*;
import waypoint.EventWaypoint;
import waypoint.MyWaypoint;
import waypoint.WaypointRender;

/**
 *
 * @author Corentin
 */
public class Carte extends javax.swing.JFrame {

    Connection con = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
        
        
    
    
    private final Set<MyWaypoint> waypoints = new HashSet<>();
    private EventWaypoint event;
    
    private static String ville;
    
    public Carte() {
        con = db.mycon();
        initComponents();
        
    }
    
    public String Ville(String str) {
            ville = str;
            //System.out.println(ville);
            return ville;
	}
    
    
    
    public void Liste(String ville){
    
        String sql = "SELECT * FROM avion WHERE VILLE_AEROCLUB = ?";
        
    
    try{
            
            
            
            pst = con.prepareCall(sql);
            pst.setString(1, ville);
            
            rs = pst.executeQuery();
            
            DefaultTableModel model = (DefaultTableModel)avionListe.getModel();
            
            while(rs.next()){
                model.addRow(new String[]{rs.getString("IMMATRICULATION"), rs.getString("TYPE"), 
                    rs.getString("REFMODELE"),rs.getString("NBPLACE"),rs.getString("PUISSANCE"), 
                    rs.getString("AUTONOMIE"), rs.getString("VILLE_AEROCLUB")});
                
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    
    
    
    }
    
    
    
    
    
    public void init(String str){
        
        
            String ville = str;
            
            String sql = "SELECT LATITUDE, LONGITUDE FROM aeroclub WHERE NOMVILLE = ?";
            
            
            try {
                
            pst = con.prepareCall(sql);
            pst.setString(1, ville);
            rs = pst.executeQuery();
            
            while (rs.next()){
            double lat = rs.getDouble("LATITUDE");
            double lon = rs.getDouble("LONGITUDE");
            
            
            TileFactoryInfo info=new OSMTileFactoryInfo();
            DefaultTileFactory tileFactory = new DefaultTileFactory(info);
            jXMapViewer.setTileFactory(tileFactory);
            GeoPosition geo = new GeoPosition(lat,lon);
            jXMapViewer.setAddressLocation(geo);
            jXMapViewer.setZoom(8);
            
            MouseInputListener mm= new PanMouseInputListener(jXMapViewer);
            jXMapViewer.addMouseListener(mm);
            jXMapViewer.addMouseMotionListener(mm);
            jXMapViewer.addMouseWheelListener(new ZoomMouseWheelListenerCenter(jXMapViewer));
            event = getEvent();
            }
            
            } catch (SQLException e) {
            System.out.println(e);
        }
        
    }
    
    
    
    private void addWaypoint(MyWaypoint waypoint){
        for(MyWaypoint d:waypoints){
            jXMapViewer.remove(d.getButton());
        }
        waypoints.add(waypoint);
        initWaypoint();
    }
    
    

    private void initWaypoint(){
        WaypointPainter<MyWaypoint> wp = new WaypointRender();
        wp.setWaypoints(waypoints);
        jXMapViewer.setOverlayPainter(wp);
        for(MyWaypoint d:waypoints){
            jXMapViewer.add(d.getButton());
        }
    }
    
    private void clearWaypoint(){
        for(MyWaypoint d:waypoints){
            jXMapViewer.remove(d.getButton());
        }
        waypoints.clear();
        initWaypoint();
    }
    
    
    private EventWaypoint getEvent(){
        return new EventWaypoint() {
            @Override
            public void selected(MyWaypoint waypoint) {
                JOptionPane.showMessageDialog(Carte.this, waypoint.getName());
            }
        
        };
    }
    
    
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jToggleButton5 = new javax.swing.JToggleButton();
        jPanel1 = new javax.swing.JPanel();
        jXMapViewer = new org.jxmapviewer.JXMapViewer();
        comboMapType = new javax.swing.JComboBox<>();
        cmdClear = new javax.swing.JButton();
        btnplus = new javax.swing.JButton();
        btnmoins = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        avionListe = new javax.swing.JTable();
        jButton3 = new javax.swing.JButton();
        btnDetails = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        comptetf = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(700, 530));
        setPreferredSize(new java.awt.Dimension(700, 530));
        setResizable(false);
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Silom", 1, 36)); // NOI18N
        jLabel2.setText("Aircraft");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(270, 20, 153, 47);

        jToggleButton5.setText("Deconnection");
        jToggleButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jToggleButton5);
        jToggleButton5.setBounds(570, 10, 121, 22);

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        comboMapType.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Open Street", "Virtual Earth", "Hybrid", "Satellite" }));
        comboMapType.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboMapTypeActionPerformed(evt);
            }
        });

        cmdClear.setText("Effacer point");
        cmdClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdClearActionPerformed(evt);
            }
        });

        btnplus.setText("+");
        btnplus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnplusMouseClicked(evt);
            }
        });
        btnplus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnplusActionPerformed(evt);
            }
        });

        btnmoins.setText("-");
        btnmoins.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnmoinsMouseClicked(evt);
            }
        });
        btnmoins.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmoinsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jXMapViewerLayout = new javax.swing.GroupLayout(jXMapViewer);
        jXMapViewer.setLayout(jXMapViewerLayout);
        jXMapViewerLayout.setHorizontalGroup(
            jXMapViewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jXMapViewerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jXMapViewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jXMapViewerLayout.createSequentialGroup()
                        .addComponent(cmdClear)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jXMapViewerLayout.createSequentialGroup()
                        .addGroup(jXMapViewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnmoins, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnplus, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 383, Short.MAX_VALUE)
                        .addComponent(comboMapType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jXMapViewerLayout.setVerticalGroup(
            jXMapViewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jXMapViewerLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jXMapViewerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboMapType, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnplus))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnmoins)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 190, Short.MAX_VALUE)
                .addComponent(cmdClear)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jXMapViewer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jXMapViewer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(81, 72, 538, 278);

        avionListe.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Immatriculation", "Type", "Ref Modele", "Nb Places", "Puissance", "Autonomie", "Localisation"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        avionListe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                avionListeMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(avionListe);

        jButton3.setText("Réserver");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        btnDetails.setText("Détails");
        btnDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDetailsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDetails, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnDetails)
                .addGap(12, 12, 12)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel3);
        jPanel3.setBounds(30, 360, 640, 120);

        jButton1.setText("Changer de ville");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(10, 10, 140, 22);
        getContentPane().add(comptetf);
        comptetf.setBounds(10, 490, 135, 18);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void comboMapTypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboMapTypeActionPerformed
        
        TileFactoryInfo info;
        int index = comboMapType.getSelectedIndex();
        
        if(index == 0){
            
            info = new OSMTileFactoryInfo();
            
        } else if(index == 1){
            
            info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.MAP);
            
        } else if(index == 2){
            
            info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.HYBRID);
            
        } else{
            
            info = new VirtualEarthTileFactoryInfo(VirtualEarthTileFactoryInfo.SATELLITE);
            
        }
        
        DefaultTileFactory tileFactory = new DefaultTileFactory(info);
        jXMapViewer.setTileFactory(tileFactory);
        
        
    }//GEN-LAST:event_comboMapTypeActionPerformed

    private void avionListeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_avionListeMouseClicked
        DefaultTableModel model = (DefaultTableModel)avionListe.getModel();
        int selectedRowIndex = avionListe.getSelectedRow();
        
        String ville = (String) avionListe.getValueAt(selectedRowIndex, 6);
        
        String sql = "SELECT NOMCLUB, LATITUDE, LONGITUDE FROM aeroclub WHERE NOMVILLE = ?";
        
    
        try{
            
            
            
            pst = con.prepareCall(sql);
            pst.setString(1, ville);
            rs = pst.executeQuery();
            
            while (rs.next()){
            double lat = rs.getDouble("LATITUDE");
            double lon = rs.getDouble("LONGITUDE");
            
            
            addWaypoint(new MyWaypoint(rs.getString("NOMCLUB"), event, new GeoPosition(lat,lon)));
            initWaypoint();
            }
            
        } catch (Exception e) {
            
        }
    }//GEN-LAST:event_avionListeMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        new ChoixVille().setVisible(true);
        this.setVisible(false);
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnplusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnplusActionPerformed
        
    }//GEN-LAST:event_btnplusActionPerformed

    private void btnmoinsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmoinsActionPerformed
        
    }//GEN-LAST:event_btnmoinsActionPerformed

    private void btnplusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnplusMouseClicked
        int zoom = jXMapViewer.getZoom() - 1;
        
        jXMapViewer.setZoom(zoom);
    }//GEN-LAST:event_btnplusMouseClicked

    private void btnmoinsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnmoinsMouseClicked
        int zoom = jXMapViewer.getZoom() + 1;
        
        jXMapViewer.setZoom(zoom);
    }//GEN-LAST:event_btnmoinsMouseClicked

    private void cmdClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdClearActionPerformed
        clearWaypoint();
    }//GEN-LAST:event_cmdClearActionPerformed

    private void btnDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDetailsActionPerformed
        
            DefaultTableModel model = (DefaultTableModel)avionListe.getModel();
            int selectedRowIndex = avionListe.getSelectedRow();
            
            String immat = (String) avionListe.getValueAt(selectedRowIndex, 0);
            
            
            Details obj= new Details();// obj created for class Second()
            obj.Detailsavion(immat);//Execute the method my_update to pass str
            obj.Liste(immat);
            obj.setVisible(true);// Open the Second.java window
            
        
    }//GEN-LAST:event_btnDetailsActionPerformed

    private void jToggleButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton5ActionPerformed
        dispose();
        Login log = new Login();
        log.setVisible(true);
    }//GEN-LAST:event_jToggleButton5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        DefaultTableModel model = (DefaultTableModel)avionListe.getModel();
            int selectedRowIndex = avionListe.getSelectedRow();
            
            String immat = (String) avionListe.getValueAt(selectedRowIndex, 0);
            
            
            Reserver obj= new Reserver();// obj created for class Second()
            obj.Reserveravion(immat);//Execute the method my_update to pass str
            obj.setVisible(true);// Open the Second.java window
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carte.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Carte().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable avionListe;
    private javax.swing.JButton btnDetails;
    private javax.swing.JButton btnmoins;
    private javax.swing.JButton btnplus;
    private javax.swing.JButton cmdClear;
    private javax.swing.JComboBox<String> comboMapType;
    private javax.swing.JLabel comptetf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JToggleButton jToggleButton5;
    private org.jxmapviewer.JXMapViewer jXMapViewer;
    // End of variables declaration//GEN-END:variables
}
