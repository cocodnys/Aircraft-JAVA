/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package waypoint;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.GeoPosition;

/**
 *
 * @author Corentin
 */
public class MyWaypoint extends DefaultWaypoint{

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the button
     */
    public JButton getButton() {
        return button;
    }

    /**
     * @param button the button to set
     */
    public void setButton(JButton button) {
        this.button = button;
    }
    
    public MyWaypoint(String name, EventWaypoint event, GeoPosition coord){
        super(coord);
        this.name = name;
        initButton(event);
    }
    
    
    public MyWaypoint(){
    
}
    
    
    private String name;
    private JButton button;
    private void initButton(EventWaypoint event){
        button = new ButtonWaypoint();
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                event.selected(MyWaypoint.this);
            }
        });
    } 
    
    
}
