/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aircraft;


import java.sql.*;
/**
 *
 * @author Corentin
 */
public class db {
 
    public static Connection mycon(){
        
        Connection con = null;
        
        try{
            
            //Class.forName("com.mysql.jdbc.Driver");
            
            con = DriverManager.getConnection("jdbc:mysql://172.28.36.9:3306/aircraftjava","c.denys","Btssio82300");
            
            
        } catch (SQLException e){
            
            System.out.println(e);
        }
        
        return con;
    }
    
    
    
}
