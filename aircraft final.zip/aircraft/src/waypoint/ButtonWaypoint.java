/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package waypoint;

import java.awt.Cursor;
import java.awt.Dimension;
import javax.swing.*;

/**
 *
 * @author Corentin
 */
public class ButtonWaypoint extends JButton{
    
    public ButtonWaypoint(){
        setContentAreaFilled(false);
        setIcon(new ImageIcon(getClass().getResource("/img/pin.png")));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setSize(new Dimension(24,24));
    }
    
}
